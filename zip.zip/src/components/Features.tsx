import { motion } from 'motion/react';
import { Wifi, BatteryCharging, Droplet, Monitor, ThermometerSnowflake, BookOpen } from 'lucide-react';

const FEATURES = [
  {
    icon: <Wifi size={24} />,
    title: 'High-Speed Wi-Fi',
    description: 'Blazing fast 300 Mbps unlimited internet for seamless video lectures and mock tests.',
  },
  {
    icon: <BatteryCharging size={24} />,
    title: '24/7 Power Backup',
    description: 'Uninterrupted studying with our robust inverter and generator backup systems.',
  },
  {
    icon: <Droplet size={24} />,
    title: 'RO Water & Hygiene',
    description: 'Unlimited purified RO drinking water and clean, well-maintained washrooms.',
  },
  {
    icon: <Monitor size={24} />,
    title: 'Ergonomic Desk Space',
    description: 'Wide, spacious desks with charging sockets and comfortable ergonomic chairs.',
  },
  {
    icon: <ThermometerSnowflake size={24} />,
    title: 'Zero-Noise Fully AC',
    description: 'Pin-drop silence in a temperature-controlled, air-conditioned environment.',
  },
  {
    icon: <BookOpen size={24} />,
    title: 'Daily Newspapers',
    description: 'Access to top daily newspapers for current affairs and general knowledge updates.',
  }
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

export function Features() {
  return (
    <section className="py-24 lg:py-32 shrink-0">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="text-center max-w-2xl mx-auto mb-16 lg:mb-24">
          <h2 className="text-sm font-bold uppercase tracking-[0.2em] mb-4 text-black/40 border-b border-black/5 pb-2 inline-block">
            Amenities
          </h2>
          <h3 className="text-4xl lg:text-5xl font-serif italic mt-6">
            Everything you need to succeed
          </h3>
        </div>

        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {FEATURES.map((feat, idx) => (
            <motion.div 
              key={idx}
              variants={item}
              className="bg-white border border-black/10 rounded-2xl p-8 hover:border-primary-gold transition-colors flex flex-col items-start"
            >
              <div className="text-primary-gold mb-6">
                {feat.icon}
              </div>
              <h4 className="text-lg font-bold mb-3">{feat.title}</h4>
              <p className="text-ink/60 text-sm leading-relaxed">
                {feat.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

import { useEffect, useState } from 'react';
import { MapPin, Moon, Sun } from 'lucide-react';
import { motion } from 'motion/react';

export function Navbar() {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    const isDarkStored = localStorage.getItem('theme') === 'dark' || 
      (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches);
    setIsDark(isDarkStored);
    if (isDarkStored) {
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = !isDark;
    setIsDark(newTheme);
    if (newTheme) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="bg-bg-light/90 backdrop-blur-md sticky top-0 z-50 border-b border-black/5 flex justify-center transition-colors duration-300"
    >
      <div className="w-full max-w-screen-2xl px-6 py-4 lg:px-12 lg:py-6 flex flex-col md:flex-row gap-6 justify-between items-center md:items-end">
        <div className="flex items-center gap-4">
          <a href="#" className="block w-16 lg:w-20 shrink-0">
            <img src="/logo.png" alt="Anushashan Logo" className="w-full h-auto object-contain mix-blend-multiply" />
          </a>
          <div className="flex flex-col mb-1 items-center md:items-start text-center md:text-left">
            <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-primary-gold mb-1">Ghaziabad, UP</span>
            <div className="text-3xl font-black italic tracking-tighter text-ink transition-colors duration-300">
              ANUSHASHAN<span className="text-primary-gold">.LIB</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-6">
          <a href="https://maps.app.goo.gl/8Ydp45qYtMH7AF8E8?g_st=aw" target="_blank" rel="noopener noreferrer" className="hidden lg:flex items-center gap-2 text-[10px] font-bold text-black/40 uppercase tracking-widest hover:text-primary-gold transition-colors">
            <MapPin size={14} className="text-primary-gold" />
            <span>Meerut Road • Sihani Chungi</span>
          </a>
          
          <button 
            onClick={toggleTheme}
            className="w-10 h-10 rounded-full border border-black/10 flex items-center justify-center text-ink hover:bg-black/5 transition-colors group"
            aria-label="Toggle theme"
          >
            {isDark ? <Sun size={16} className="text-primary-gold" /> : <Moon size={16} className="group-hover:text-primary-gold transition-colors" />}
          </button>

          <a 
            href="#booking-section"
            className="px-8 py-3 bg-primary-gold text-white text-[11px] uppercase tracking-widest font-black rounded-full hover:opacity-90 transition-opacity whitespace-nowrap"
          >
            Secure Seat
          </a>
        </div>
      </div>
    </motion.nav>
  );
}

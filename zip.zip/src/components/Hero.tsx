import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, Wifi, Zap, Clock } from 'lucide-react';

const IMAGES = [
  '/1.jpg',
  '/2.jpg',
  '/3.jpg',
  '/4.jpg',
  '/5.jpg',
  '/6.jpg',
  '/7.jpg'
];

export function Hero() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % IMAGES.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="bg-primary-navy text-white min-h-[85vh] flex justify-center relative overflow-hidden">
      <div className="w-full max-w-screen-2xl flex flex-col lg:flex-row relative z-10">
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="w-full lg:w-5/12 p-12 xl:p-20 flex flex-col justify-between border-r border-white/5 bg-primary-navy"
        >
          <div>
            <div className="flex items-center gap-4 mb-8">
              <span className="w-12 h-px bg-primary-gold"></span>
              <span className="text-primary-gold text-[10px] uppercase tracking-widest font-bold">Absolute Focus</span>
            </div>
            
            <h1 className="text-6xl lg:text-7xl xl:text-8xl font-display italic leading-[0.9] mb-8">
              The <br />Silent<br /> <span className="text-primary-gold">Sanctuary.</span>
            </h1>
            
            <p className="text-white/60 mt-6 text-sm max-w-[280px] leading-relaxed mb-12">
              Premium study environment engineered for JEE, NEET, and UPSC aspirants who demand absolute focus.
            </p>

            <a href="#pricing" className="inline-flex items-center gap-4 px-8 py-4 bg-primary-gold text-white text-[11px] uppercase tracking-widest font-black rounded-full hover:bg-white hover:text-ink transition-colors group">
              View Pricing 
              <ArrowRight className="group-hover:translate-x-1 transition-transform" size={16} />
            </a>
          </div>
          
          <div className="grid grid-cols-2 gap-x-8 gap-y-6 pt-12 mt-12 border-t border-white/10">
            <div>
              <h4 className="text-[10px] uppercase font-bold text-white/40 mb-2 tracking-tighter">Connectivity</h4>
              <div className="flex gap-2 items-center text-sm font-semibold">
                <Wifi size={16} className="text-primary-gold"/> 300 Mbps Wi-Fi
              </div>
            </div>
            <div>
              <h4 className="text-[10px] uppercase font-bold text-white/40 mb-2 tracking-tighter">Power Supply</h4>
              <div className="flex gap-2 items-center text-sm font-semibold">
                <Zap size={16} className="text-primary-gold"/> 24/7 Backup
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.2, delay: 0.2 }}
          className="w-full lg:w-7/12 relative h-[500px] lg:h-auto min-h-full"
        >
          <AnimatePresence mode="popLayout">
            <motion.img
              key={currentImageIndex}
              src={IMAGES[currentImageIndex]}
              alt="Library Interior"
              initial={{ opacity: 0, scale: 1.05 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8 }}
              className="absolute inset-0 w-full h-full object-cover"
            />
          </AnimatePresence>
          <div className="absolute inset-0 bg-primary-navy/20 mix-blend-multiply"></div>
          
          {/* Floating badge */}
          <div className="absolute bottom-8 right-8 bg-white p-5 rounded-xl text-center border border-black/10 shadow-xl opacity-90 text-ink transition-colors duration-300">
            <div className="text-[10px] uppercase font-bold text-primary-gold mb-1">Status</div>
            <div className="text-lg font-bold">85% Full</div>
            <div className="text-[9px] text-green-600 font-bold uppercase mt-1">Live availability</div>
          </div>
        </motion.div>
      </div>
      {/* Background bleed for left side on very large screens */}
      <div className="absolute left-0 top-0 bottom-0 w-1/2 bg-primary-navy z-0"></div>
    </section>
  );
}

import { motion } from 'motion/react';
import { Star } from 'lucide-react';

const TESTIMONIALS = [
  {
    name: 'Rahul Sharma',
    exam: 'JEE Aspirant',
    text: 'The best part about Anushashan is the absolute silence. The chairs are very comfortable for 10+ hours of sitting. Highly recommend to everyone.',
    rating: 5,
  },
  {
    name: 'Priya Verma',
    exam: 'NEET Aspirant',
    text: 'High-speed Wi-Fi never drops. I am able to watch all my live classes without buffering. The management is very supportive.',
    rating: 5,
  },
  {
    name: 'Amit Singh',
    exam: 'UPSC Aspirant',
    text: 'Safe and secure environment. The daily newspaper access is a great addition for current affairs. Good power backup too.',
    rating: 5,
  }
];

export function Testimonials() {
  return (
    <section className="py-24 lg:py-32 bg-white border-t border-black/5">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="text-center max-w-2xl mx-auto mb-16 lg:mb-24">
          <h2 className="text-sm font-bold uppercase tracking-[0.2em] mb-4 text-black/40 border-b border-black/5 pb-2 inline-block">
            Student Experiences
          </h2>
          <h3 className="text-4xl lg:text-5xl font-serif italic mt-6">
            Hear from our members
          </h3>
        </div>

        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {TESTIMONIALS.map((t, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="p-8 rounded-2xl bg-bg-light border border-black/10 flex flex-col h-full hover:border-primary-gold transition-colors"
            >
              <div className="flex gap-1 mb-8">
                {[...Array(t.rating)].map((_, i) => (
                  <Star key={i} size={14} className="fill-primary-gold text-primary-gold" />
                ))}
              </div>
              <p className="text-ink/80 leading-relaxed font-serif text-lg italic mb-10 grow">
                "{t.text}"
              </p>
              <div className="flex items-center gap-4 mt-auto border-t border-black/5 pt-6">
                <div>
                  <h4 className="font-bold text-ink text-sm">{t.name}</h4>
                  <p className="text-[10px] text-primary-gold font-bold uppercase tracking-widest mt-1">{t.exam}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { Phone, MapPin, Mail, Instagram, Facebook } from 'lucide-react';

export function Footer() {
  return (
    <>
      <section className="bg-primary-navy text-white py-24 lg:py-32 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 grid lg:grid-cols-2 gap-16 relative z-10">
          <div>
            <h2 className="text-sm font-bold uppercase tracking-[0.2em] mb-4 text-white/40 border-b border-white/5 pb-2 inline-block">
              Get in touch
            </h2>
            <h3 className="text-4xl lg:text-5xl font-serif italic mt-6 mb-12">
              Contact Us.
            </h3>
            
            <div className="space-y-10">
              <div className="flex items-start gap-4">
                <Phone size={20} className="text-primary-gold shrink-0 mt-1" />
                <div>
                  <p className="text-[10px] uppercase font-bold text-white/40 mb-1 tracking-widest">Call / WhatsApp</p>
                  <p className="text-2xl font-bold font-serif italic">+91 70332 39457</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <MapPin size={20} className="text-primary-gold shrink-0 mt-1" />
                <div>
                  <p className="text-[10px] uppercase font-bold text-white/40 mb-1 tracking-widest">Address</p>
                  <p className="text-lg leading-relaxed text-white/80 font-serif italic mb-3">
                    Meerut Road Sihani Chungi,<br />
                    Near Khushi Boutique, Ghaziabad,<br />
                    Uttar Pradesh.
                  </p>
                  <a 
                    href="https://maps.app.goo.gl/8Ydp45qYtMH7AF8E8?g_st=aw" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-[10px] uppercase font-bold tracking-widest text-primary-gold hover:text-white transition-colors"
                  >
                    View on Google Maps →
                  </a>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <Mail size={20} className="text-primary-gold shrink-0 mt-1" />
                <div>
                  <p className="text-[10px] uppercase font-bold text-white/40 mb-1 tracking-widest">Email</p>
                  <p className="text-lg font-serif italic text-white/80">contact@anushashanlib.com</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col justify-end lg:items-end">
             <div className="text-left lg:text-right">
                <div className="flex items-center gap-4 lg:justify-end mb-4">
                  <a href="#" className="block w-16 lg:w-20 shrink-0">
                    <img src="/logo.png" alt="Anushashan Logo" className="w-full h-auto object-contain bg-bg-light rounded-2xl shadow-xl" />
                  </a>
                  <div className="text-4xl font-black italic tracking-tighter">
                    ANUSHASHAN<span className="text-primary-gold">.LIB</span>
                  </div>
                </div>
                <p className="text-white/60 text-sm max-w-[280px] leading-relaxed mb-8 ml-0 lg:ml-auto">
                  Premium study environment engineered for JEE, NEET, and UPSC aspirants who demand absolute focus.
                </p>
                
                <div className="flex gap-4 lg:justify-end">
                  <a href="#" className="w-10 h-10 border border-white/20 rounded-full flex items-center justify-center hover:bg-primary-gold hover:border-transparent transition-colors text-white">
                    <Instagram size={16} />
                  </a>
                  <a href="#" className="w-10 h-10 border border-white/20 rounded-full flex items-center justify-center hover:bg-primary-gold hover:border-transparent transition-colors text-white">
                    <Facebook size={16} />
                  </a>
                </div>
             </div>
          </div>
        </div>

        {/* Decorative Image Background */}
        <div className="absolute bottom-0 right-0 w-1/2 h-[120%] bg-primary-navy mix-blend-overlay opacity-30 select-none pointer-events-none overflow-hidden">
          <div className="w-full text-white/5 text-[240px] font-serif italic leading-none whitespace-nowrap absolute right-0 bottom-0 transform translate-x-1/4 translate-y-1/4 select-none">
            Focus
          </div>
        </div>
      </section>

      <footer className="py-8 bg-bg-light border-t border-black/5 relative">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 flex flex-col md:flex-row justify-between items-center gap-4">
           <p className="text-[10px] uppercase tracking-widest font-bold text-black/40">
             © {new Date().getFullYear()} Anushashan Premium Study Spaces
           </p>
           <p className="text-[10px] uppercase tracking-widest font-bold text-black/40">
             Ghaziabad, UP
           </p>
        </div>

        {/* Subtle Vertical Text Decor */}
        <div className="hidden lg:block absolute bottom-12 left-6 [writing-mode:vertical-rl] text-[9px] uppercase tracking-[0.5em] font-bold text-black/20 pointer-events-none">
          © {new Date().getFullYear()} ANUSHASHAN PREMIUM STUDY SPACES
        </div>
      </footer>
    </>
  );
}

import { useState, useEffect } from 'react';
import { 
  auth, 
  db, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  updateProfile, 
  logOut 
} from '../firebase';
import { collection, addDoc, query, orderBy, onSnapshot, serverTimestamp } from 'firebase/firestore';
import { onAuthStateChanged, User } from 'firebase/auth';
import { MessageSquare, LogIn, LogOut, Send, Mail, Lock, User as UserIcon, Star } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Comment {
  id: string;
  text: string;
  userName: string;
  createdAt: any;
  rating?: number;
}

export function Comments() {
  const [user, setUser] = useState<User | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [rating, setRating] = useState(5);
  
  // Auth Form States
  const [isAuthFormOpen, setIsAuthFormOpen] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [authError, setAuthError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        setIsAuthFormOpen(false);
      }
    });

    const q = query(collection(db, 'comments'), orderBy('createdAt', 'desc'));
    const unsubscribeDb = onSnapshot(
      q, 
      (snapshot) => {
        setComments(snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as Comment[]);
      },
      (error) => {
        console.error("Firestore Error: You probably need to update your Firebase Security Rules to allow public reads. Error details:", error);
      }
    );

    return () => {
      unsubscribeAuth();
      unsubscribeDb();
    };
  }, []);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setIsLoading(true);

    try {
      if (isSignUp) {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        await updateProfile(userCredential.user, { displayName: name });
        // Force refresh user state with display name
        setUser({ ...userCredential.user, displayName: name });
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
      setEmail('');
      setPassword('');
      setName('');
    } catch (error: any) {
      console.error('Auth error:', error);
      if (error.code === 'auth/email-already-in-use') {
        setAuthError('Email already in use. Please sign in instead.');
      } else if (error.code === 'auth/wrong-password' || error.code === 'auth/user-not-found' || error.code === 'auth/invalid-credential') {
        setAuthError('Invalid email or password.');
      } else {
        setAuthError('Authentication failed. Please check your details.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !user) return;

    try {
      await addDoc(collection(db, 'comments'), {
        text: newComment,
        rating: rating,
        userName: user.displayName || email.split('@')[0],
        userId: user.uid,
        createdAt: serverTimestamp()
      });
      setNewComment('');
      setRating(5);
    } catch (error) {
      console.error('Error adding comment: ', error);
      alert('Error posting your comment. Please try again.');
    }
  };

  return (
    <section className="py-24 lg:py-32 bg-bg-light border-t border-black/5">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <div className="text-center mb-16 lg:mb-20">
          <h2 className="text-sm font-bold uppercase tracking-[0.2em] mb-4 text-black/40 border-b border-black/5 pb-2 inline-block">
            Community Board
          </h2>
          <h3 className="text-4xl lg:text-5xl font-serif italic mt-6">
            Student Comments
          </h3>
        </div>

        <div className="bg-white rounded-2xl border border-black/10 overflow-hidden">
          {/* Header & Auth Actions */}
          <div className="p-6 border-b border-black/5 flex flex-col sm:flex-row justify-between items-center gap-4 bg-gray-50/50">
            <div className="flex items-center gap-3">
              <MessageSquare className="text-primary-gold" size={24} />
              <h4 className="font-bold text-lg">Leave a Review</h4>
            </div>
            
            {user ? (
              <div className="flex items-center gap-4">
                <span className="text-sm font-bold text-ink/60">Hi, {user.displayName || user.email?.split('@')[0]}</span>
                <button 
                  onClick={logOut}
                  className="px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-ink hover:text-red-500 transition-colors flex items-center gap-2"
                >
                  <LogOut size={14} />
                  Sign Out
                </button>
              </div>
            ) : (
              !isAuthFormOpen && (
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => { setIsSignUp(true); setIsAuthFormOpen(true); }}
                    className="px-6 py-3 bg-ink text-white text-[10px] font-black uppercase tracking-widest rounded-full hover:bg-black transition-colors"
                  >
                    Register
                  </button>
                  <button 
                    onClick={() => { setIsSignUp(false); setIsAuthFormOpen(true); }}
                    className="px-6 py-3 bg-primary-gold text-white text-[10px] font-black uppercase tracking-widest rounded-full hover:bg-ink transition-colors flex items-center gap-2"
                  >
                    <LogIn size={14} />
                    Sign In
                  </button>
                </div>
              )
            )}
          </div>

          {/* Embedded Auth Form */}
          <AnimatePresence>
            {!user && isAuthFormOpen && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="border-b border-black/5 overflow-hidden bg-white relative"
              >
                <div className="absolute top-4 right-4">
                  <button 
                    onClick={() => setIsAuthFormOpen(false)}
                    className="w-8 h-8 rounded-full bg-black/5 flex items-center justify-center text-ink/50 hover:bg-black/10 hover:text-ink transition-colors"
                  >
                    ×
                  </button>
                </div>
                <div className="p-8 lg:p-12 max-w-sm mx-auto">
                  <div className="text-center mb-8">
                    <h5 className="font-serif italic text-2xl mb-2">{isSignUp ? 'Join Anushashan' : 'Welcome Back'}</h5>
                    <p className="text-xs text-ink/50 uppercase tracking-widest font-bold">
                      {isSignUp ? 'Create an account to review' : 'Sign in to leave a review'}
                    </p>
                  </div>

                  {authError && (
                    <div className="mb-6 p-3 bg-red-50 border border-red-100 text-red-600 text-xs rounded-lg text-center">
                      {authError}
                    </div>
                  )}

                  <form onSubmit={handleAuth} className="flex flex-col gap-4">
                    {isSignUp && (
                      <div className="relative">
                        <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-ink/40" size={16} />
                        <input
                          type="text"
                          placeholder="Your Name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="w-full pl-12 pr-4 py-3 bg-bg-light border border-black/10 rounded-xl focus:border-primary-gold outline-none text-sm transition-colors"
                          required
                        />
                      </div>
                    )}
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-ink/40" size={16} />
                      <input
                        type="email"
                        placeholder="Email Address"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-12 pr-4 py-3 bg-bg-light border border-black/10 rounded-xl focus:border-primary-gold outline-none text-sm transition-colors"
                        required
                      />
                    </div>
                    <div className="relative">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-ink/40" size={16} />
                      <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full pl-12 pr-4 py-3 bg-bg-light border border-black/10 rounded-xl focus:border-primary-gold outline-none text-sm transition-colors"
                        required
                        minLength={6}
                      />
                    </div>
                    
                    <button 
                      type="submit"
                      disabled={isLoading}
                      className="w-full py-3 mt-2 bg-ink text-white text-xs font-bold uppercase tracking-widest rounded-xl hover:bg-primary-gold disabled:opacity-50 transition-colors"
                    >
                      {isLoading ? 'Processing...' : (isSignUp ? 'Create Account' : 'Sign In')}
                    </button>
                    
                    <div className="text-center mt-4">
                      <button 
                        type="button"
                        onClick={() => { setIsSignUp(!isSignUp); setAuthError(''); }}
                        className="text-xs text-ink/60 hover:text-primary-gold transition-colors underline underline-offset-4"
                      >
                        {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
                      </button>
                    </div>
                  </form>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Comment Form */}
          {user && (
            <div className="p-6 border-b border-black/5 bg-white">
              <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                <div className="flex items-center gap-1">
                  <span className="text-xs uppercase tracking-widest font-bold text-ink/40 mr-2">Rate Us</span>
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className="focus:outline-none transition-transform hover:scale-110"
                    >
                      <Star 
                        size={20} 
                        className={star <= rating ? "text-primary-gold" : "text-black/10"} 
                        fill={star <= rating ? "currentColor" : "none"} 
                      />
                    </button>
                  ))}
                </div>
                <div className="flex gap-4">
                  <input
                    type="text"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Share your experience at Anushashan..."
                    className="flex-grow p-4 bg-bg-light border border-black/10 rounded-xl focus:border-primary-gold outline-none transition-colors text-sm"
                    required
                  />
                  <button 
                    type="submit"
                    disabled={!newComment.trim()}
                    className="px-6 py-4 bg-ink text-white rounded-xl hover:bg-primary-gold disabled:opacity-50 transition-colors flex items-center justify-center gap-2 shrink-0 w-16"
                  >
                    <Send size={18} />
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Comments List */}
          <div className="p-6 flex flex-col gap-6 max-h-[500px] overflow-y-auto">
            {comments.length === 0 ? (
              <div className="text-center text-ink/40 py-10 text-sm font-medium">
                No comments yet. Be the first to share your experience!
              </div>
            ) : (
              comments.map((comment) => (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={comment.id} 
                  className="pb-6 border-b border-black/5 last:border-0 last:pb-0"
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 shrink-0 rounded-full bg-primary-gold/10 text-primary-gold flex items-center justify-center font-bold text-sm uppercase">
                      {comment.userName ? comment.userName.charAt(0).toUpperCase() : 'S'}
                    </div>
                    <div>
                      <div className="flex items-center gap-3">
                        <h5 className="font-bold text-sm text-ink">{comment.userName || 'Student'}</h5>
                        <div className="flex items-center gap-0.5">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star 
                              key={star}
                              size={12} 
                              className={star <= (comment.rating || 5) ? "text-primary-gold" : "text-black/10"} 
                              fill={star <= (comment.rating || 5) ? "currentColor" : "none"} 
                            />
                          ))}
                        </div>
                      </div>
                      <span className="text-[10px] text-ink/40 font-medium tracking-widest uppercase mt-0.5 block">
                        {comment.createdAt?.toDate ? comment.createdAt.toDate().toLocaleDateString() : 'Just now'}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-ink/80 leading-relaxed font-serif pl-[52px]">
                    {comment.text}
                  </p>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

import { motion } from 'motion/react';
import { Check } from 'lucide-react';

const PLANS = [
  {
    name: 'Morning Prime',
    price: '600',
    time: '08:00 AM — 02:00 PM',
    features: ['6 Hours Access', 'High-Speed Wi-Fi', 'AC Environment'],
    highlighted: false,
    delay: 0
  },
  {
    name: 'Executive All-Access',
    price: '1200',
    time: '08:00 AM — 09:00 PM',
    features: ['13 Hours Access', 'Reserved Fixed Seat', 'High-Speed Wi-Fi', 'AC Environment'],
    highlighted: true,
    delay: 0.1
  },
  {
    name: 'Evening Focus',
    price: '700',
    time: '02:00 PM — 09:00 PM',
    features: ['7 Hours Access', 'High-Speed Wi-Fi', 'AC Environment'],
    highlighted: false,
    delay: 0.2
  }
];

export function Pricing() {
  const handleSelectPlan = (planName: string) => {
    const selectEl = document.getElementById('shift') as HTMLSelectElement;
    if (selectEl) {
      const option = Array.from(selectEl.options).find(opt => opt.value.includes(planName) || planName.includes(opt.value.split(' ')[0]));
      if (option) {
        selectEl.value = option.value;
      }
    }
  };

  return (
    <section id="pricing" className="py-24 lg:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 flex flex-col items-center">
        <div className="text-center mb-16 lg:mb-24 w-full">
          <h2 className="text-sm font-bold uppercase tracking-[0.2em] mb-4 text-black/40 border-b border-black/5 pb-2 inline-block">
            Membership Tiers
          </h2>
          <h3 className="text-4xl lg:text-5xl font-serif italic mt-6">
            Simple, Transparent Pricing
          </h3>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto w-full items-start">
          {PLANS.map((plan, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: plan.delay }}
              className={`p-8 rounded-2xl flex flex-col h-full border ${
                plan.highlighted 
                  ? 'bg-primary-navy border-transparent text-white shadow-xl' 
                  : 'bg-white text-ink border-black/10 hover:border-primary-gold transition-colors'
              }`}
            >
              <div className="mb-8">
                <span className={`text-[10px] uppercase font-bold tracking-widest block mb-2 ${plan.highlighted ? 'text-primary-gold' : 'text-black/30'}`}>
                  {plan.time}
                </span>
                <h4 className={`text-xl font-bold ${plan.highlighted ? 'italic' : ''}`}>{plan.name}</h4>
              </div>
              
              <div className="mb-6 flex items-baseline gap-1">
                <span className={`text-3xl font-black ${plan.highlighted ? 'text-primary-gold' : ''}`}>₹{plan.price}</span>
                <span className={`text-[10px] uppercase font-bold tracking-widest ${plan.highlighted ? 'opacity-60' : 'opacity-40'}`}>
                  /MO
                </span>
              </div>
              
              <ul className="space-y-4 mb-8 flex-1">
                {plan.features.map((feat, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <Check size={14} className={plan.highlighted ? 'text-primary-gold' : 'text-black/40'} />
                    <span className="text-sm font-medium opacity-80">
                      {feat}
                    </span>
                  </li>
                ))}
              </ul>

              <a
                href="#booking-section"
                onClick={() => handleSelectPlan(plan.name)}
                className={`block w-full py-4 text-center rounded-full text-[11px] uppercase font-bold tracking-widest transition-colors ${
                  plan.highlighted
                    ? 'bg-primary-gold text-white hover:bg-white hover:text-ink'
                    : 'border border-black/10 hover:bg-ink hover:text-white hover:border-transparent'
                }`}
              >
                Select Tier
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

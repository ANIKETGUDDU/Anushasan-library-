import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown } from 'lucide-react';

const FAQS = [
  {
    q: 'Can I choose a specific seat?',
    a: 'Yes, if you opt for the Full Day access plan, you get a reserved fixed seat for the entire month. For other plans, seats are on a first-come, first-serve basis within your shift time.'
  },
  {
    q: 'Is the library open on Sundays?',
    a: 'Yes! The library is open 7 days a week, 365 days a year. We understand that competitive exams require consistent preparation.'
  },
  {
    q: 'What happens during power cuts?',
    a: 'We have 24/7 robust power backup with heavy-duty inverters and generators, so your AC and Wi-Fi will never be interrupted.'
  },
  {
    q: 'Is it safe for female students?',
    a: 'Absolutely. We have CCTV surveillance and a very strict discipline policy to ensure a safe and comfortable environment for everyone.'
  }
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-24 lg:py-32 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-12">
        <div className="text-center mb-16 lg:mb-24">
          <h2 className="text-sm font-bold uppercase tracking-[0.2em] mb-4 text-black/40 border-b border-black/5 pb-2 inline-block">
            Information
          </h2>
          <h3 className="text-4xl lg:text-5xl font-serif italic mt-6">
            Frequently Asked Questions
          </h3>
        </div>

        <div className="space-y-2">
          {FAQS.map((faq, idx) => (
            <div 
              key={idx} 
              className="border-b border-black/10"
            >
              <button
                onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
                className="w-full text-left py-6 font-bold text-lg flex items-center justify-between"
              >
                <span className={openIndex === idx ? 'text-primary-gold' : 'text-ink'}>{faq.q}</span>
                <ChevronDown 
                  size={20} 
                  className={`transition-transform duration-300 ${openIndex === idx ? 'rotate-180 text-primary-gold' : 'text-black/40'}`} 
                />
              </button>
              <AnimatePresence>
                {openIndex === idx && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="pb-8 pt-0 text-ink/60 leading-relaxed font-medium">
                      {faq.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { FormEvent } from 'react';
import { motion } from 'motion/react';
import { MessageCircle } from 'lucide-react';

export function Booking() {
  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const name = (form.elements.namedItem('name') as HTMLInputElement).value;
    const phone = (form.elements.namedItem('phone') as HTMLInputElement).value;
    const shift = (form.elements.namedItem('shift') as HTMLSelectElement).value;
    
    const msg = `*Admission Query - Anushashan Lib*%0A%0A*Name:* ${name}%0A*Phone:* ${phone}%0A*Shift:* ${shift}%0A%0APlease confirm seat availability.`;
    window.open(`https://wa.me/917033239457?text=${msg}`, '_blank');
  };

  return (
    <section id="booking-section" className="py-24 lg:py-32 bg-bg-light relative overflow-hidden">
      <div className="max-w-xl mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-white p-10 lg:p-14 rounded-2xl border border-black/10 relative"
        >
          <div className="text-center mb-10">
            <h3 className="text-3xl lg:text-4xl font-serif italic mb-2">Reserve Your Seat</h3>
            <p className="text-black/40 text-[10px] uppercase font-bold tracking-widest mt-4">Direct Admission via WhatsApp</p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-[10px] uppercase font-bold text-black/40 mb-2 tracking-widest">Full Name</label>
              <input 
                type="text" 
                id="name" 
                name="name"
                placeholder="Student Name" 
                required 
                className="w-full text-sm py-3 border-b border-black/20 bg-transparent focus:border-primary-gold outline-none transition-colors font-medium placeholder:text-black/20"
              />
            </div>
            
            <div>
              <label htmlFor="phone" className="block text-[10px] uppercase font-bold text-black/40 mb-2 tracking-widest">Mobile Number</label>
              <input 
                type="tel" 
                id="phone" 
                name="phone"
                placeholder="+91" 
                required 
                className="w-full text-sm py-3 border-b border-black/20 bg-transparent focus:border-primary-gold outline-none transition-colors font-medium placeholder:text-black/20"
              />
            </div>
            
            <div>
              <label htmlFor="shift" className="block text-[10px] uppercase font-bold text-black/40 mb-2 tracking-widest">Preferred Tier</label>
              <select 
                id="shift" 
                name="shift"
                className="w-full text-sm py-3 border-b border-black/20 bg-transparent focus:border-primary-gold outline-none transition-colors font-medium appearance-none cursor-pointer"
              >
                <option value="Morning Prime">Morning Prime (08:00 AM - 02:00 PM)</option>
                <option value="Executive All-Access">Executive All-Access (08:00 AM - 09:00 PM)</option>
                <option value="Evening Focus">Evening Focus (02:00 PM - 09:00 PM)</option>
              </select>
            </div>
            
            <button 
              type="submit" 
              className="w-full bg-[#128C7E] px-8 py-4 text-[#ffffff] text-[11px] uppercase tracking-widest font-black rounded-full flex justify-center items-center gap-3 mt-8 hover:bg-primary-navy transition-colors"
            >
              <MessageCircle size={18} />
              Secure My Seat Now
            </button>

            <div className="pt-6 border-t border-black/5 mt-6 text-center">
               <p className="text-black/40 text-[10px] uppercase font-bold tracking-widest mb-4">Or Visit Us Directly</p>
               <a 
                 href="https://maps.app.goo.gl/8Ydp45qYtMH7AF8E8?g_st=aw" 
                 target="_blank" 
                 rel="noopener noreferrer"
                 className="w-full border border-black/10 px-8 py-4 text-ink hover:text-white text-[11px] uppercase tracking-widest font-black rounded-full flex justify-center items-center gap-3 hover:bg-ink transition-all"
               >
                 Get Directions
               </a>
            </div>
          </form>
        </motion.div>
      </div>
    </section>
  );
}

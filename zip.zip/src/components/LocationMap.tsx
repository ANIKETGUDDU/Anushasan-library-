import { MapPin, Navigation } from 'lucide-react';
import { motion } from 'motion/react';

export function LocationMap() {
  return (
    <section className="py-24 bg-white border-t border-black/5">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-sm font-bold uppercase tracking-[0.2em] mb-4 text-black/40 border-b border-black/5 pb-2 inline-block">
            Location
          </h2>
          <h3 className="text-4xl lg:text-5xl font-serif italic mt-6">
            Visit Anushashan
          </h3>
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative max-w-5xl mx-auto"
        >
          <a 
            href="https://maps.app.goo.gl/8Ydp45qYtMH7AF8E8?g_st=aw"
            target="_blank"
            rel="noopener noreferrer"
            className="block relative w-full h-[400px] lg:h-[500px] rounded-3xl overflow-hidden group bg-bg-light border border-black/10 shadow-lg"
          >
            {/* Map background placeholder styling */}
            <div 
              className="absolute inset-0 opacity-50 group-hover:opacity-70 transition-opacity duration-700 bg-cover bg-center mix-blend-multiply"
              style={{ backgroundImage: "url('https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=2000&auto=format&fit=crop')" }}
            />
            
            {/* Overlay to ensure text readability */}
            <div className="absolute inset-0 bg-primary-navy/10 group-hover:bg-primary-navy/0 transition-colors duration-700" />
            
            <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
              {/* Pulsing Map Marker */}
              <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-2xl mb-6 group-hover:scale-110 transition-transform duration-500 text-primary-gold relative z-10">
                <div className="absolute inset-0 bg-primary-gold/30 rounded-full animate-ping" />
                <MapPin size={32} className="relative z-10" />
              </div>
              
              {/* Location Card Details */}
              <div className="bg-white/95 backdrop-blur-sm p-8 rounded-2xl shadow-xl max-w-md transform group-hover:-translate-y-2 transition-transform duration-500 border border-black/5">
                <h4 className="font-bold text-2xl mb-3 font-serif italic">Anushashan Library</h4>
                <p className="text-sm text-ink/70 mb-8 font-medium leading-relaxed">
                  Meerut Road Sihani Chungi,<br />
                  Near Khushi Boutique, Ghaziabad,<br />
                  Uttar Pradesh.
                </p>
                
                <div className="inline-flex items-center justify-center gap-3 bg-ink text-white px-8 py-4 rounded-full text-[11px] font-black uppercase tracking-widest group-hover:bg-primary-gold transition-colors w-full sm:w-auto">
                  <Navigation size={16} />
                  Get Live Directions
                </div>
              </div>
            </div>
          </a>
        </motion.div>
      </div>
    </section>
  );
}

import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile
} from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyDwoHgz7Ed91cwkQrRggHyB4h8fnjTuJnk",
  authDomain: "study-track-db3d5.firebaseapp.com",
  projectId: "study-track-db3d5",
  storageBucket: "study-track-db3d5.firebasestorage.app",
  messagingSenderId: "62161722012",
  appId: "1:62161722012:web:ce202c2937e77654ff6b59"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();

export const signInWithGoogle = () => {
  return signInWithPopup(auth, googleProvider);
};

export const logOut = () => {
  return signOut(auth);
};

export { createUserWithEmailAndPassword, signInWithEmailAndPassword, updateProfile };

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { Pricing } from './components/Pricing';
import { FAQ } from './components/FAQ';
import { Booking } from './components/Booking';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Comments } from './components/Comments';
import { LocationMap } from './components/LocationMap';

export default function App() {
  return (
    <div className="font-sans antialiased text-ink bg-bg-light">
      <Navbar />
      <Hero />
      <Features />
      <Pricing />
      <Comments />
      <FAQ />
      <LocationMap />
      <Booking />
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}

Place your logo.png or logo.svg in this directory so the app can access it.
